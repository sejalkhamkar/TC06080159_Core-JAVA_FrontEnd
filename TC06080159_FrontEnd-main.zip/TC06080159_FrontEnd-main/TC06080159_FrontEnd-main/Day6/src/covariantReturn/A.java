package covariantReturn;

public class A {
	
	A get() {
		return this;
	}
}
