package interfaceExample;

public interface Factorial {
	
	public abstract int fact(int n);
}
