package interfaceExample;

public interface StaticCal {
	
	int avg(int a , int b);

}
