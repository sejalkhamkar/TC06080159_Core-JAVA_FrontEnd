package interfaceExample;

public class CompareCal {
	
	public int min(int a , int b) {
		int min = (a < b) ? a : b;
		return min;
	}

}
