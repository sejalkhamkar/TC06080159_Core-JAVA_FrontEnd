package interfaceExample;

public class Test {
	
	Calculations c = new Calculations();

	

}
