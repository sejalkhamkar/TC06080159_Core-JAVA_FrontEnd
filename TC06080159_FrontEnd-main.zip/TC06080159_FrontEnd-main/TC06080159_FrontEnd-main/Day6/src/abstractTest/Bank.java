package abstractTest;

public abstract class Bank {
	
	public abstract float getROI();

}
