package abstractTest;

public class SBI extends Bank{

	@Override
	public float getROI() {
		return 5.5f;
	}

}
