package abstractTest;

public abstract class Shape {
	
	public abstract double area();

}
