package abstractTest;

public class BOI extends Bank{

	@Override
	public float getROI() {
		return 6.5f;
	}

}
