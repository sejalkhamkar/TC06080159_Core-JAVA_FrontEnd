
public class Tile {
	
	double edge;

    public Tile(double edge) {
        this.edge = edge;
    }

}
