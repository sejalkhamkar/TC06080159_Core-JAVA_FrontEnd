package que42;

public class Student {
	
	private int rollNo;
	private float percentage;
	
	public Student() {
		
	}
	public Student(int rollNo , float percentage) {
		this.rollNo = rollNo;
		this.percentage = percentage;
	}
	

}
