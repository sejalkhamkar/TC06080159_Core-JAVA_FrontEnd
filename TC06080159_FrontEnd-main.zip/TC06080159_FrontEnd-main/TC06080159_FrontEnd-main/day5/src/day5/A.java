package day5;

public class A {
	
	final int a;
	
	A(){
		a = 100;
	}
	
	public void getA() {
		System.out.println("In getA() of Class A");
	}

}
