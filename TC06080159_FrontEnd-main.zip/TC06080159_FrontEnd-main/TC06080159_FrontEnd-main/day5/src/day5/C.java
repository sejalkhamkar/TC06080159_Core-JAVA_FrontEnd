package day5;

public class C {
	
	public C() {
		System.out.println("Parent Default");
	}
	
	public C(int a) {
		System.out.println("Parent Parameterized");
	}

}
