
public class FinalKeyword {
	
	//Final 
	//class - cannot be inherited
	//member - cannot be reinitialized
	// method - cannot be overriden
	
	
	//System.out.println
	//System is a final class
	//out is a static member of System class and which is type of PrintStream(println)
	

}
