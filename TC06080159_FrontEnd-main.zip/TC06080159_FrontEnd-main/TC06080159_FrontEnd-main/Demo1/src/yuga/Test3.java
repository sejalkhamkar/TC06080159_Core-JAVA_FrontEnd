package yuga;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int id;
		String name;
		float marks;
		
		

	}

}
