package yuga;

import java.util.Scanner;

public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
//		int i;
//		int j;
//		
//		for(i=1;i<=5;i++);
//		{
//			for(j=1;j<=i;j++)
//			{
//				System.out.print("*");
//				j++;
//			}
//			System.out.println("");
//			i++;
			
		// }
		
		
//		int i=1;
//		do {
//			System.out.println(i);
//			i++;	
//		} while(i<=5);
		
//		int fact=1;
//		int i=5;
//		
//		do {
//			fact=fact*i;
//			
//			
//			i--;
//		} while(i>=1);
//		System.out.println(fact);
		
		
		
		
//		int n;
//		Scanner sc =new Scanner(System.in);
//		n=sc.nextInt();
//		boolean flag = true;
//		
//		int i=2;
//		
//		while(i<n/2)
//		{
//			if(n%i==0)
//			{
//				flag=false;
//			}
//			i++;
//		}
//		if(flag=true) {
//			
//			System.out.println("Prime Number");
//		}
//		else {
//			System.out.println("Not Prime Number");
//		}
		// Prime number
		
		
//		int value=6,i;
//		boolean flag=true;
//		for(i=2;i<value/2;i++)
//		{
//			if(value%i==0)
//			{
//				flag=false;
//			}
//			if(flag==true) {
//				System.out.println("Prime Number");
//			}
//			else {
//				System.out.println("Not Prime Number");
//			}
//		}
		

	}

}
