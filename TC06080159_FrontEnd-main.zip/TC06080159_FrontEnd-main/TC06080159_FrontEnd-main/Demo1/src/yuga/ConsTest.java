package constructor_try;

public class ConsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int id;
		String name;
		float salary;
		public ConsTest()
		{
			id=1001;
			name= "Esha";
			salary= 40000;
		}
		public void showData() {
			System.out.println(id+" "+name+" "+salary+" ");
		}
		

	}

}
