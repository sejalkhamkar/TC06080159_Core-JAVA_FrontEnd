public class Student {
	
	String name;
    int rollNo;
    int age;
    double score;
    
	public Student(String name, int rollNo, int age, double score) {
		super();
		this.name = name;
		this.rollNo = rollNo;
		this.age = age;
		this.score = score;
	}

}
